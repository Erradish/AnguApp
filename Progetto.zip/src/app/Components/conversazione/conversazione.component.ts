import { Component, Input } from '@angular/core';
import { User } from 'src/app/Interfaces/user';

@Component({
  selector: 'app-conversazione',
  templateUrl: './conversazione.component.html',
  styleUrls: ['./conversazione.component.css']
})
export class ConversazioneComponent {
  @Input() destinatario!:User
}
