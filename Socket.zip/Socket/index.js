const app = require('express')();
const httpServer = require('http').createServer(app);
const io = require('socket.io')(httpServer, {
  cors: {origin : 'http://localhost:4200'}
});
const http = require('node:http');

const port = process.env.PORT || 3000;
const users = [];

io.on('connection', (socket) => {

  socket.on("join", (data) => {
    console.log(data)
    console.log('User '+ data.UserName + ' connected'); // world
    users.push({
      username: data.UserName,
      id: socket.id,
      img:data.Img,
      mail:data.Mail,
      number:data.Number,
    });

    io.emit('personeconnesse',users)
  });


  socket.on('message', (data) => {

    io.to(socket.id).emit('message',data);

    var index = users.findIndex(function(element) {
      return element.username === data.nome; 
    });
    console.log(index)
    io.to(users[index].id).emit('message',data)
    
    data = JSON.stringify(data); 
    
    var options = {
      host: 'localhost',
      port: 80,
      path: '/PHP/SalvaMessaggi.php',
      method: 'POST'
    };
    
    
  const req = http.request(options, (res) => {
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
      console.log(`BODY: ${chunk}`);
    });
    res.on('end', () => {
      console.log('No more data in response.');
    });
  });

  req.on('error', (e) => {
    console.error(`problem with request: ${e.message}`);
  });

  // Write data to request body
  req.write(data);
  req.end(); 

  });

  socket.on('disconnect', () => { 
    var disc = socket.id
    var index = users.findIndex(function(element) {
      return element.id === disc; 
    });

    if (index !== -1) {
      users.splice(index, 1);
    }
  });
});

httpServer.listen(port, () => console.log(`listening on port ${port}`));