import { Injectable } from '@angular/core';
import { Socket } from 'ngx-socket-io';
import { Message } from '../Interfaces/message';
import { LocalstorageService } from './localstorage.service';
import { User } from '../Interfaces/user';

@Injectable({
  providedIn: 'root'
})
export class SocketService {
  //Ogni volte che qualcuno di connette o disconnete, restituisce un array di persone connesse
  personeConnesse = this.socket.fromEvent<User[]>('personeconnesse')
  messaggi = this.socket.fromEvent<any>('message')

  user:User

  constructor(private socket:Socket, private localStorage:LocalstorageService) { 
    
    this.user = this.localStorage.read('user');

    socket.connect()
    socket.emit('join',this.user)
  }
  
  sendMessage(messaggion:Message) {
    this.socket.emit('message',messaggion)
  }
}
