import { Component, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { User } from 'src/app/Interfaces/user';
import { ApiService } from 'src/app/Services/api.service';
import { LocalstorageService } from 'src/app/Services/localstorage.service';

@Component({
  selector: 'app-popupprofilo',
  templateUrl: './popupprofilo.component.html',
  styleUrls: ['./popupprofilo.component.css']
})
export class PopupprofiloComponent {
  form: any
  dati!:any
  constructor(
    private dialogRef: MatDialogRef<PopupprofiloComponent>, // il riferimento alla modal
    @Inject(MAT_DIALOG_DATA) public data:any, // sono i dati che passo alla modal (o popup)
    private storage:LocalstorageService,
    private api:ApiService,
    private fb: FormBuilder,
    ) { 
      this.dati = data
      this.form = this.fb.group({
        img: [this.data.Img, Validators.required],
      })
      
    }

    
    submit(){
      const img = this.form.value
      this.api.update(this.dati.UserName, img.img).subscribe((res)=>{
        this.chiudi()
    })
    }
    chiudi() {
      this.dialogRef.close()
    }
  
}
