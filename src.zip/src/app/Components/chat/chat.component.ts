import { Component, Input } from '@angular/core';
import { Message } from 'src/app/Interfaces/message';
import { User } from 'src/app/Interfaces/user';
import { LocalstorageService } from 'src/app/Services/localstorage.service';
import { SocketService } from 'src/app/Services/socket.service';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
  
  @Input() destinatario!:User
  @Input() messaggi:Message[]=[]
  testoMessaggio: string="";

  constructor(private socketService: SocketService, private localStorage:LocalstorageService) { 
    
  }

  mandaMessaggio(){
    const messaggio : Message ={
      nome : this.destinatario.username,
      TimeSent: new Date().toISOString(),
      Sender : this.localStorage.read('user').UserName,
      Text: this.testoMessaggio 
    }
    this.socketService.sendMessage(messaggio)
    this.messaggi.push(messaggio)
    this.testoMessaggio = ""
  }

}
