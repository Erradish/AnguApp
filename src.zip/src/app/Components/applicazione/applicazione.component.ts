import { Component } from '@angular/core';
import { Message } from 'src/app/Interfaces/message';
import { User } from 'src/app/Interfaces/user';
import { ApiService } from 'src/app/Services/api.service';
import { LocalstorageService } from 'src/app/Services/localstorage.service';
import { SocketService } from 'src/app/Services/socket.service';

@Component({
  selector: 'app-applicazione',
  templateUrl: './applicazione.component.html',
  styleUrls: ['./applicazione.component.css']
})
export class ApplicazioneComponent {

  persone:any[] = []
  chatAperta!:User
  messaggi: Message[]=[];
  notificheDa:{nome:string, tot:number}[] = []

  constructor(private socketService: SocketService, private localStorageService: LocalstorageService, private api:ApiService) {
    
    socketService.personeConnesse.subscribe((result) => {
      this.persone = result
      console.log(this.persone)
    })

    this.socketService.messaggi.subscribe((response) => {
      response.letto = false
      this.getMessaggiFiltrati(this.chatAperta.username)
      console.log(response)
      this.salvaMessaggi()

    })
  }

  setChat(persona:User){
    this.messaggi = []
    this.chatAperta = persona
    this.getMessaggiFiltrati(persona.username)
  }

  getMessaggiFiltrati(nome:string){
    const user = this.localStorageService.read('user')
    this.api.messaggi(user.UserName, nome).subscribe((res)=>{
      const Messaggivecchi = res
      if(Messaggivecchi.length > 0) {
        this.messaggi = Messaggivecchi
        console.log(this.messaggi)
      }
      this.messaggi.forEach((m:Message)=>{
        if(m.Sender == nome){
          m.letto = true
          m.ricevuto = true
        }
      }
      )
      this.salvaMessaggi()
    })

  }

  salvaMessaggi(){
    this.localStorageService.save(this.messaggi,'messaggi')
  }
}
