export interface User {
    username: string;
    img:string,
    mail:string,
    number:string,
}
