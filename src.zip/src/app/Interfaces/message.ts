export interface Message {
    nome?:string,
    Sender?:string,
    TimeSent?:string,
    Text:string,
    ricevuto?:boolean,
    letto?:boolean,
}
